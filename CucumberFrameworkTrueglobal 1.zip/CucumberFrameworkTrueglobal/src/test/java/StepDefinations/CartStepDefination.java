// I have declared this class for the stepdefination, it gives the idea to us about what step are goint in our framework
package StepDefinations;

import org.openqa.selenium.WebDriver;

import PageObjectModel.AddCartPageObject;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CartStepDefination {
	
	WebDriver driver=null; 
	AddCartPageObject obj;  // globally declare the page object model class to accces the properties 
	
	@Given("Initilize the driver")  // here driver is initilalize for opening of browser
	public void initilize_the_driver() {
	    
	}

	@When("user enter to url {string}")
	public void user_enter_to_url(String string) {
		
	  obj=new AddCartPageObject(driver);  // url has been open
	}

	@Then("user click on search bar and ente Iphone {int} pro max")
	public void user_click_on_search_bar_and_ente_iphone_pro_max(Integer int1) {
	   
		obj.searchbar("Iphone 15 pro max"); // add the sring in search bar
	}

	@Then("click on search button or enter")
	public void click_on_search_button_or_enter() {
		
		obj.searchbtn(); // clicked on search button
	    
	}

	@Then("Product will be displayed on the screen")
	public void product_will_be_displayed_on_the_screen() {
		
		obj.clickonproduct(); // clicked on product button
	    
	}

	@Then("user click on Add to cart button")
	public void user_click_on_add_to_cart_button() {
		
		obj.Addcartbtn(); // clicked on add o cart button
	    
	}

	@Then("product will be added to the add to cart")
	public void product_will_be_added_to_the_add_to_cart() {
		
		obj.showcartbtn(); // clicked product added in cart button
	    
	}


}
