// Here i have created pom file that indicate the design pattern
package PageObjectModel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AddCartPageObject {
	
	WebDriver driver; 
	
	By txt_searchbar=By.id("twotabsearchtextbox");  // x-path for the search bar
	
	By txt_searchbtn=By.id("nav-search-submit-button"); // x-path for the search button
	
	By txt_clickonproduct=By.className("a-size-medium a-color-base a-text-normal"); // x-path for the product link on that link we will click for display the product
	
	
	By txt_Addcartbtn=By.id("add-to-cart-button"); // x-path for the add to cart button
	
	By txt_showcartbtn=By.className("a-button-input"); // x-path for the show the added product on my cart button
	
	
	public AddCartPageObject(WebDriver driver) { // Here I have declared the value of one driver and acces this driver in other package
		
		
		this.driver=driver;
	}
	
	
	
	public void searchbar(String phonename) {   // after click on search bar it will search for iphone 15 pro max
		
		driver.findElement(txt_searchbar).sendKeys(phonename);
		
	}
	
	public void searchbtn() {
		
		driver.findElement(txt_searchbtn).click(); // we return this statement for  the click on search button
	}
	
	public void clickonproduct() {
		
		driver.findElement(txt_clickonproduct).click();  // we return this statement for  the click on product button
	}
	
	public void Addcartbtn() { //  I have return this statement for  the add product into cart
		
		driver.findElement(txt_Addcartbtn).click();
	}
	public void showcartbtn() { // //  I have return this statement for  the show added product in cart
		
		driver.findElement(txt_showcartbtn).click();
	}

}
